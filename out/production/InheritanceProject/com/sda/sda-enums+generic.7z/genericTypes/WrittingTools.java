package com.sda.genericTypes;

public class WrittingTools {
    // tema de completat cu atribute si metode
}
