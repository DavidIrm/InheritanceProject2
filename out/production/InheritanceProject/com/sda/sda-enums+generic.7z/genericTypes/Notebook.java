package com.sda.genericTypes;

public class Notebook {
    // tema de completat cu atribute si metode


    public void noteStuff(){
        System.out.println("Notting");
    }
}
