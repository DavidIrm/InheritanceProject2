package com.sda.genericTypes;

public class GenericMain {

    static public void main(String args[]) {
/*
        Book myBook = new Book();
        Book myBook2 = new Book();
        Notebook myNotebok = new Notebook();
        WrittingTools myWrittningTools = new WrittingTools();


        Library<Book> library22 = new Library<>(myBook2);
        Library<Notebook> library2 = new Library<>(myNotebok);
        Library<WrittingTools> library3 = new Library<>(myWrittningTools);
        library2.getItem().noteStuff();



        Library<Book> library1 = new Library<>(myBook);
        library1.makeCommonStuff(myBook);
        library1.getItem().read();


        library2.makeCommonStuff(myNotebok);*/


        System.out.println("Messaj pe mai multe linii"+5);

        boolean b = (5<4)&&(4>3);
        boolean b2 = (5<6)||(4>3);

/*

        

        Library library1 = new Library(myBook);
        Library library2 = new Library(myNotebok);
        Library library3 = new Library(myWrittningTools);

        library1.item.read();
        library2.item.noteStuff();




*/

    }
}
