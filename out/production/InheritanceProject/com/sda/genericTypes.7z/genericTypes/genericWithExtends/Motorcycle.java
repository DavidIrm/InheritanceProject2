package com.sda.genericTypes.genericWithExtends;

/**
 *
 * @Author  MihaiP
 */
public class Motorcycle extends Vehicle implements VehicleComparatorInterface<Car>{

    private String model;

    public Motorcycle(String model, int year) {
        super(year);
        this.model = model;

    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    @Override
    public String toString() {
        return "Motorcycle{" +
                "model='" + model + '\'' +
                "year='" + super.getYear() + '\'' +
                '}';
    }

    @Override
    public void compareVehicle(Car vehicle) {
        if(this.getYear()<vehicle.getYear()){
            System.out.println();
        }

    }
}
