package com.sda.genericTypes.genericWithExtends;

public interface myclass {
}
