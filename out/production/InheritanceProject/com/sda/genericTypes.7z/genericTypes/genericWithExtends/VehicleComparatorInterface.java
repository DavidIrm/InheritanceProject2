package com.sda.genericTypes.genericWithExtends;

public interface VehicleComparatorInterface<M> {

    void compareVehicle(M vehicle);

}
