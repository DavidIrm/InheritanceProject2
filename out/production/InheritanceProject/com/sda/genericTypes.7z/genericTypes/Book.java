package com.sda.genericTypes;

public class Book {
    // tema de completat cu atribute si metode


    public  void read(){
        System.out.println("Reading Books");
    }
}
