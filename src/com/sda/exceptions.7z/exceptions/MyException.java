package com.sda.exceptions;

public class MyException extends Exception{

  /*  public MyException()*/
}
